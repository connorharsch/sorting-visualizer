package visualizer.v1_7;

public class Quick {
    
    
}
