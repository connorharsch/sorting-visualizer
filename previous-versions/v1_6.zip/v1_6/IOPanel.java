package visualizer.v1_6;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class IOPanel extends JPanel{
    
    JFrame window;
    
    static JPanel buttons;
    static JPanel output;
    ContentPanel cp;

    static JLabel labelArray;
    JButton start = new JButton("start");
    JButton reset = new JButton("reset");

    GridBagConstraints gbc = new GridBagConstraints();


    IOPanel(JFrame w, ContentPanel c){
        window = w;
        cp = c;
        setLayout(new GridBagLayout());
        buttons = new JPanel();
        output = new JPanel();

        add(output);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(buttons,gbc);

        labelArray = new JLabel("-");
        labelArray.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        labelArray.setForeground(Color.BLACK);
        labelArray.setVisible(true);
        output.add(labelArray);

        start.setBackground(Color.WHITE);
        start.setFocusPainted(false);
        start.setBorderPainted(false);
        start.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!cp.isRunning){
                    try {
                        cp.isRunning = true;
                        cp.getPanelSize();
                        cp.genArray();
                        labelArray.setVisible(true);
                        cp.animate();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }});
        
        reset.setBackground(Color.WHITE);
        reset.setFocusPainted(false);
        reset.setBorderPainted(false);
        reset.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    cp.isRunning = false;
                    labelArray.setText("-");
                    ContentPanel.array_index = 0;
                    ContentPanel.compare_index = Integer.MAX_VALUE;
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                
            }});

        buttons.add(start);
        buttons.add(reset);
    }   
}