package visualizer.v1_6;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MasterPanel extends JPanel {
    static JFrame w = new JFrame("Bubblesort Visualizer Alpha v1.6");
    static ContentPanel cp = new ContentPanel(w);
    static IOPanel io = new IOPanel(w,cp);

    MasterPanel(){
        w.add(cp, BorderLayout.CENTER);
        w.add(io, BorderLayout.SOUTH);
        w.setSize(400,400);
        w.setLocationRelativeTo(null);
        w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        w.setVisible(true);
    }

    public static void main(String[] args){
        new MasterPanel();
        Thread t = new Thread(new RunClock(w,cp,io));
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}