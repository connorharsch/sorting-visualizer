package visualizer.v1_1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class ContentPanel extends JPanel implements Runnable{
    
    private static final long serialVersionUID = 1L;
    private static int[] array = new int[80];
    private int array_index;
    private int compare_index;

    private int screenWidth = 800;
    private int screenHeight = 640;

    private boolean isRunning;

    JButton start = new JButton("start");
    JButton reset = new JButton("reset");
    JFrame window;
    Thread thread;
    int FPS = 60;

    public void startThread() {
        thread = new Thread(this);
        thread.start();
    }

    public ContentPanel(JFrame w){
        array_index = 0;
        compare_index = Integer.MAX_VALUE;

        genArray();

        window = w;
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.setFocusable(true);
        this.setLayout(null);

        start.setBackground(Color.WHITE);
        start.setFocusPainted(false);
        start.setBorderPainted(false);
        start.setBounds(screenWidth/2, screenHeight-200, 100, 50);
        start.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                if(!isRunning){
                    try {
                        isRunning = true;
                        BubbleSortAnimate();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }});
        
        reset.setBackground(Color.WHITE);
        reset.setFocusPainted(false);
        reset.setBorderPainted(false);
        reset.setBounds(screenWidth/3, screenHeight-100, 100, 50);
        reset.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    genArray();
                    compare_index = Integer.MAX_VALUE;
                    array_index = 0;
                    isRunning = false;
                    repaint();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                
            }});

        add(start);
        add(reset);
        
    }

    public void genArray() {
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * (screenHeight/2 - 90) + 40);
        }
    }

    public void sortOnlyOneItem(){
        if(array[compare_index] > array[compare_index+1]) {
            int temp = array[compare_index];
            array[compare_index] = array[compare_index+1];
            array[compare_index+1] = temp;
        }

        if((compare_index+1) >= (array.length - array_index - 1)){
            array_index++;
            compare_index = 0;
        }

        else compare_index++;
    }
    
    public static boolean isSorted() {
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] > array[i + 1]) {
                return false;
            }
        }
        return true;
    }
    public void BubbleSortAnimate() throws Exception {
        
        compare_index = 0;

        Timer timer = new Timer(1, new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                if(isSorted()){
                    compare_index = Integer.MAX_VALUE;
                    ((Timer)e.getSource()).stop();
                } else{
                    if(isRunning){
                        sortOnlyOneItem();
                    }
                    repaint();
                }
            }
        });
        timer.start();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000 / FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (thread != null) {
    
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if(delta >= 1){
                update();
                repaint();
                delta--;
                drawCount++;
            }

            if(timer >= 1000000000){
                System.out.println("FPS: " + drawCount);
                System.out.println(screenWidth + " x " + screenHeight);
                drawCount = 0;
                timer = 0;
            }
        }
    }
    
    public void update() {
        Rectangle r = window.getBounds();
        if(r.height != screenHeight){
            isRunning = false;
            array_index = 0;
            compare_index = Integer.MAX_VALUE;
            genArray();
            repaint();
        }
        if(r.width != screenWidth){
            isRunning = false;
            array_index = 0;
            compare_index = Integer.MAX_VALUE;
            genArray();
            repaint();
        }
        screenWidth = r.width;
        screenHeight = r.height;
        start.setBounds(screenWidth/2 - 50, (screenHeight/3) + (screenHeight/4), 100, 50);
        reset.setBounds(screenWidth/2 - 50, (screenHeight/2) + (screenHeight/4), 100, 50);
    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        this.setBackground(Color.BLACK);

        Rectangle r = new Rectangle(0,0,screenWidth,screenHeight/2);
        g.setColor(Color.GRAY);
        g.fillRect(r.x,r.y,r.width,r.height);
        

        int rectWidth = 0;
        int rectOrigin = 0;
        
        if(array.length < 255){
            rectWidth = (screenWidth/array.length) -2;
            rectOrigin = rectWidth+1;

            for(int i = 0; i < array.length; i++){
                g.setColor(Color.WHITE);
    
                if(i == compare_index){
                    g.setColor(Color.RED);
                }
                
                int start = (screenWidth - (rectOrigin * array.length))/2;
                g.drawRect(start + (i*rectOrigin), screenHeight/2 - (array[i]) - 1, rectWidth, array[i]);
                
                g.setColor(Color.BLACK);
                g.fillRect(start + (i*rectOrigin+1), screenHeight/2 - array[i], rectWidth-1, array[i]);
                
            }
        }else{
            rectWidth = 1;
            rectOrigin = 4;

            for(int i = 0; i < array.length; i++){
                g.setColor(Color.WHITE);
    
                if(i == compare_index){
                    g.setColor(Color.RED);
                }
    
                int start = (screenWidth - (rectOrigin * array.length))/2;
                g.drawRect(start + (i*rectOrigin), screenHeight/2 - array[i]-1, rectWidth, array[i]);
            }
        }
    }
}
