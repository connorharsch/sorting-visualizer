package visualizer.v1_2;

import javax.swing.JFrame;

public class TestWindow extends JFrame{
    
    public static void main(String[] args){
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(true);
        window.setTitle("Bubblesort Visualizer Alpha v1.2");
        
        ContentPanel cp = new ContentPanel(window);
        window.add(cp);

        window.pack();

        window.setLocationRelativeTo(null);
        window.setVisible(true);

        cp.startThread();
    }
}
