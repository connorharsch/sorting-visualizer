package visualizer.v1_3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class ContentPanel extends JPanel implements Runnable{
    
    private static final long serialVersionUID = 1L;
    private static int[] array = new int[80];
    private int array_index;
    private int compare_index;
    private int screenWidth = 800;
    private int screenHeight = 640;

    private int rectWidth = 0;
    private int rectOrigin = 0;
    private boolean isRunning;

    private Rectangle r;
    
    JButton start = new JButton("start");
    JButton reset = new JButton("reset");
    JFrame window;
    Thread thread;
    int FPS = 60;

    public void startThread() {
        thread = new Thread(this);
        thread.start();
    }

    public ContentPanel(JFrame w){
        array_index = 0;
        compare_index = Integer.MAX_VALUE;

        genArray();

        window = w;
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.setFocusable(true);
        this.setLayout(null);
        window.setTitle("Bubblesort Visualizer Alpha v1.3");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(true);
        

        start.setBackground(Color.WHITE);
        start.setFocusPainted(false);
        start.setBorderPainted(false);
        start.setBounds(screenWidth/2 - 50, screenHeight-200, 100, 50);
        start.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                if(!isRunning){
                    try {
                        isRunning = true;
                        getScreenSize();
                        genArray();
                        repaint();
                        animate();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }});
        
        reset.setBackground(Color.WHITE);
        reset.setFocusPainted(false);
        reset.setBorderPainted(false);
        reset.setBounds(screenWidth/2 - 50, screenHeight-100, 100, 50);
        reset.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    isRunning = false;
                    array_index = 0;
                    compare_index = Integer.MAX_VALUE;
                    genArray();
                    repaint();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                
            }});

        add(start);
        add(reset);
        
    }

    public void genArray() {
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * (screenHeight * 5/8));
        }
    }
    
    public static boolean issorted() {
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] > array[i + 1]) {
                return false;
            }
        }
        return true;
    }

    public void animate(){
        
        compare_index = 0;
        Timer timer = new Timer(100, new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                if(issorted()){
                    compare_index = Integer.MAX_VALUE;
                    ((Timer)e.getSource()).stop();
                } else{
                    if(isRunning){
                        sort();
                    }
                    repaint();
                }
            }
        });
        timer.start();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000 / FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (thread != null) {
    
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if(delta >= 1){
                update();
                repaint();
                delta--;
                drawCount++;
            }

            if(timer >= 1000000000){
                System.out.println("FPS: " + drawCount + " : " + array.length);
                System.out.println(screenWidth + " x " + screenHeight);
                
                drawCount = 0;
                timer = 0;
            }
        }
    }
    
    public void update() {
        getScreenSize();
        start.setBounds(screenWidth/2 - 100, screenHeight * 3/4, 100, 50);
        reset.setBounds(screenWidth/2, screenHeight * 3/4, 100, 50);
    }

    private void getScreenSize() {
        r = window.getBounds();
        if(r.height != screenHeight || r.width != screenWidth){
            isRunning = false;
            array_index = 0;
            compare_index = Integer.MAX_VALUE;
            int newArraySize = (r.width/8);
            if(newArraySize > 0){
                array = new int[newArraySize];
            }
            genArray();
            repaint();
        }
        screenWidth = r.width;
        screenHeight = r.height;
    }

    public void sort(){
        if(array[compare_index] > array[compare_index+1]) {
            int temp = array[compare_index];
            array[compare_index] = array[compare_index+1];
            array[compare_index+1] = temp;
        }

        if((compare_index+1) >= (array.length - array_index - 1)){
            array_index++;
            compare_index = 0;
        }

        else compare_index++;
    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        this.setBackground(Color.BLACK);

        Rectangle r = new Rectangle(0,0, screenWidth, screenHeight/2 + screenHeight/5);
        g.setColor(Color.GRAY);
        g.fillRect(r.x,r.y,r.width,r.height);
        
        rectWidth = (screenWidth/array.length) -2;
        rectOrigin = rectWidth+1;
        if(isRunning){
            for(int i = 0; i < array.length; i++){
                g.setColor(Color.WHITE);
    
                if(i == compare_index){
                    g.setColor(Color.RED);
                }
                
                int start = (screenWidth - (rectOrigin * array.length))/2 - 5;
                g.drawRect(start + (i*rectOrigin), (screenHeight/2 + screenHeight/5) - (array[i]) - 1, rectWidth, array[i]);
                
                g.setColor(Color.BLACK);
                g.fillRect(start + (i*rectOrigin+1), (screenHeight/2 + screenHeight/5) - array[i], rectWidth-1, array[i]);
                
            } 
        }
               
    }
}
