package visualizer.v1_3;

import javax.swing.JFrame;

public class TestWindow extends JFrame{
    
    public static void main(String[] args){
        JFrame window = new JFrame();
        ContentPanel cp = new ContentPanel(window);
        window.add(cp); //add cp to window
        window.pack(); //applies layout/subcomponents from cp to window

        window.setLocationRelativeTo(null); //create new window in middle of screen
        window.setVisible(true);

        cp.startThread(); //start the cp threa
    }
}
